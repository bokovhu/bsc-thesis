package me.bokov.bsc.surfaceviewer.glsl;

public abstract class GLSLStatement {

    public abstract String getKind();

    public abstract String render();

}
