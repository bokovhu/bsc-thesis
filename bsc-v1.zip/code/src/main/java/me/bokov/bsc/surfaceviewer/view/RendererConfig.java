package me.bokov.bsc.surfaceviewer.view;

import java.io.Serializable;

public interface RendererConfig extends Serializable {
}
